init
% Turn draw to ture if you would like to see what's happening during learning
draw=false;
run_num=1;

while success_rate<0.8
    current_state=[pac_man_state,ghost_state,1];
    current_path=current_state;
    run_num
    it_num=1;
    while (current_state(4)~=4)&&(current_state(4)~=5)
        
        for each_action=1:5
            available_Qs(each_action)=Q{each_action}(current_state(1),current_state(2),current_state(3),current_state(4));
        end
        available_Qs=available_Qs';
        [sorted_available_Qs,sortingIndices] = sort(available_Qs,'descend');
        hom_many_maxes=find(ismember(sorted_available_Qs,sorted_available_Qs(1)));
        action_with_max_Q=sortingIndices(floor(hom_many_maxes(end)*rand)+1);
         
        %%Epsilon Greedy
        starting_probab=0.8;
        epsilon=((1-starting_probab)/(50000-1))*(run_num-1)+starting_probab;
        if rand>epsilon
            next_state=take_action(current_state,floor(5*rand)+1);
        else
            next_state=take_action(current_state,action_with_max_Q);
        end
         
        for each_action=1:5
            available_Qs_2(each_action)=Q{each_action}(next_state(1),next_state(2),next_state(3),next_state(4));
        end
        
        number_of_visits{action_with_max_Q}(current_state(1),current_state(2),current_state(3))=...
        number_of_visits{action_with_max_Q}(current_state(1),current_state(2),current_state(3))+1;    
        alpha=1/(number_of_visits{action_with_max_Q}(current_state(1),current_state(2),current_state(3))^omega);
        Q{action_with_max_Q}(current_state(1),current_state(2),current_state(3),current_state(4))=(1-alpha)*...
        Q{action_with_max_Q}(current_state(1),current_state(2),current_state(3),current_state(4))+alpha*(...
        objective1r(current_state(4),next_state(4))+...
        discount_factor*max(available_Qs_2));
     
        current_state=next_state;
         
        current_path=[current_path;current_state];
        available_Qs=[];
        
        if current_state(4)==4
            disp('success!')
        end
        
        if draw
            hold on
            if current_state(4)==1
                img = imread('init.png');
            elseif current_state(4)==2
                img = imread('number_1_eaten.png');
            elseif current_state(4)==3
                img = imread('number_2_eaten.png');
            elseif current_state(4)==4
                img = imread('all_eaten.png');
            else
                img = imread('init.png');
                img=255-img;
            end
            image('CData',img,'XData',[1 size(layout_mat,2)*100],'YData',[1 size(layout_mat,1)*100])
            h(4)=image(xlim,-ylim,img);
            agent_current_location=state2location(current_state(1));tmp=agent_current_location;agent_current_location=(agent_current_location).*100+50;
            h(1)=plot(agent_current_location(2),agent_current_location(1),'.','MarkerSize', 100,'MarkerFaceColor','y','MarkerEdgeColor','y');
            for i=1:size(current_state,2)-2
                ghost_current_location(i,:)=state2location(current_state(2+i-1));ghost_current_location(i,:)=(ghost_current_location(i,:)).*100+50;
                h(i+1)=plot(ghost_current_location(i,2),ghost_current_location(i,1),'.','MarkerSize', 100,'MarkerFaceColor','r','MarkerEdgeColor','r');
            end
            view(0,-90)
            xlim([1 size(layout_mat,2)*100])
            ylim([1 size(layout_mat,1)*100])
            title(['Current Location: (',int2str(tmp),'  ',int2str(current_state(4)),')'])
            pbaspect([size(layout_mat,2) size(layout_mat,1) 1])
            drawnow
            pause(.2)  
        end
        it_num=it_num+1;
    end
        accepted_pathes{run_num}=current_path;
        if current_state(4)==4
            target_time(run_num)=size(current_path,1);
            success_numbers=success_numbers+1;
        else
            target_time(run_num)=inf;
        end
        success_rate=success_numbers/(run_num/3.3);
        run_num=run_num+1;
end
 
plot(target_time)
[minv,mini]=min(target_time);
animate_run
  