function r=objective1r(current_state3,next_state3)
if next_state3==4
    r=1;
elseif next_state3==5
    r=-1;
else
    r=0;
end