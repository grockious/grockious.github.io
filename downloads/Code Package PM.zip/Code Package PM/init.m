clc
clear all
close all

%%Hyper-parameters
discount_factor=0.99;
alpha=0.99;
omega=0.79;
success_rate=0;
success_numbers=0;

global ghosts_determinism
ghosts_determinism=0.9; % from 0 to 1, what is the probability of ghosts to go towards pacman at each iteration 

load('layout.mat','layout_matrix')
global layout_mat
layout_mat=layout_matrix;
clearvars layout_matrix

global a b ghost neutral wall_loc ghost_loc pac_mac_loc empty_space food_loc
a=1;
b=2;
ghost=3;
neutral=4;
wall_loc=37;
ghost_loc=71;
pac_mac_loc=80;
food_loc=46;
empty_space=32;


%%Defining the area assuming that there is always a wall around
global X_movable_limit Y_movable_limit
X_movable_limit=size(layout_mat,1)-2;
Y_movable_limit=size(layout_mat,2)-2;
X=linspace(1,X_movable_limit,X_movable_limit);
Y=linspace(1,Y_movable_limit,Y_movable_limit)';
[x,y]=meshgrid(X,Y);
 
%%Q function
total_number_of_states=X_movable_limit*Y_movable_limit;
for action_indx=1:5
    Q{action_indx}=zeros(total_number_of_states,total_number_of_states,total_number_of_states,5);
end
number_of_visits=Q;

%%Initializations
[r,c]=find(ismember(layout_mat,pac_mac_loc));
pac_man_location=[r-1,c-1];
pac_man_state=location2state(pac_man_location);

[r,c]=find(ismember(layout_mat,ghost_loc));
ghost_location=[r-1,c-1];
ghost_state=location2state(ghost_location);

%%Creating MDP graph
global G
G=[1;1];
layout_mat_temp=layout_mat;
for state=1:total_number_of_states
    location=state2location(state);
    location=location+1;
    if layout_mat_temp(location(1),location(2))~=wall_loc
        for i=-2:2
            add=sign(i).*de2bi(abs(i),2);
            next_location(1)=location(1)+add(2);
            next_location(2)=location(2)+add(1);
            if layout_mat_temp(next_location(1),next_location(2))~=wall_loc
                G=[G,[state;location2state(next_location-1)]];
                layout_mat_temp(location(1),location(2))=wall_loc;
            end   
        end
    end
end
G(:,1)=[];




