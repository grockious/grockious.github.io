function next_automaton_state = automaton (u,last_automaton_state)
global a b ghost neutral
switch last_automaton_state
    case 1
        if u == neutral
            next_automaton_state=1;
        elseif u==a
            next_automaton_state=2;
        elseif u==b
            next_automaton_state=3;
        elseif u == ghost
            next_automaton_state=5;
        end
    case 2
        if u == neutral
            next_automaton_state=2;
        elseif u==a
            next_automaton_state=2;
        elseif u==b
            next_automaton_state=4;
        elseif u == ghost
            next_automaton_state=5;
        end
    case 3
        if u == neutral
            next_automaton_state=3;
        elseif u==a
            next_automaton_state=4;
        elseif u==b
            next_automaton_state=3;
        elseif u == ghost
            next_automaton_state=5;
        end
    case 4
        next_automaton_state=4;
    case 5
        next_automaton_state=5;
end