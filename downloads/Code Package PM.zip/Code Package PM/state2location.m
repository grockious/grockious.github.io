function location=state2location(state)
global X_movable_limit
location=[];
for i=1:size(state,2)
    l1=mod(state(i)-1,X_movable_limit)+1;
    l2=floor((state(i)-1)/X_movable_limit)+1;
    location=[location;l1,l2];
end