function action_indx=determine_action(current_location,next_location)
binary=[next_location(2)-current_location(2) next_location(1)-current_location(1)];
if min(min(binary))==-1
    action_indx=5-bi2de(abs(binary));
elseif binary(1)==1
    action_indx=2;
elseif binary(2)==1
    action_indx=1;
else
    action_indx=5;
end
