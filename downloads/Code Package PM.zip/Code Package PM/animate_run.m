close all
current_location=state2location(accepted_pathes{mini}(1,1));
%
v = VideoWriter('animation.avi');
v.FrameRate = 2;  
v.Quality = 100;
open(v);
view(0,-90)
pacman_l = imread('pacman_l.png');
pacman_r = imread('pacman_r.png');
pacman_dir = pacman_r;
pacman_u = imread('pacman_u.png');
pacman_d = imread('pacman_d.png');
markersize_pacman = [45,45]; 
markersize_ghosts = [40,40];

for i=1:5
    current_location=state2location(accepted_pathes{mini}(1,1));
    hold on
    img = imread('init.png');
    image('CData',img,'XData',[1 size(layout_mat,2)*100],'YData',[1 size(layout_mat,1)*100])
    h(4)=image(xlim,-ylim,img);
    agent_current_location=state2location(accepted_pathes{mini}(1,1));tmp=agent_current_location;
    agent_current_location=(agent_current_location).*100+50;
    imagesc([agent_current_location(2)-markersize_pacman(1) agent_current_location(2)+markersize_pacman(1)],...
        [agent_current_location(1)-markersize_pacman(2) agent_current_location(1)+markersize_pacman(2)],pacman_r);
    for j=1:size(accepted_pathes{mini}(1,:),2)-2
        ghost_current_location(j,:)=state2location(accepted_pathes{mini}(1,2+j-1));ghost_current_location(j,:)=(ghost_current_location(j,:)).*100+50;
        imagesc([ghost_current_location(j,2)-markersize_ghosts(1) ghost_current_location(j,2)+markersize_ghosts(1)],...
        [ghost_current_location(j,1)-markersize_ghosts(2) ghost_current_location(j,1)+markersize_ghosts(2)],imread(sprintf('ghost%d.png',j)));
    end
    view(0,-90)
    xlim([1 size(layout_mat,2)*100])
    ylim([1 size(layout_mat,1)*100])
    title(['Current Location: (',int2str(tmp),'  ',int2str(accepted_pathes{mini}(1,4)),')'])
    pbaspect([size(layout_mat,2) size(layout_mat,1) 1])
    drawnow
    pause(.2)
    frame = getframe;
    writeVideo(v,frame);
end

for run_num=1:size(accepted_pathes{mini},1)
    current_location=state2location(accepted_pathes{mini}(run_num,1));
    hold on
    if accepted_pathes{mini}(run_num,4)==1
            img = imread('init.png');
        elseif accepted_pathes{mini}(run_num,4)==2
            img = imread('number_1_eaten.png');
        elseif accepted_pathes{mini}(run_num,4)==3
            img = imread('number_2_eaten.png');
        elseif accepted_pathes{mini}(run_num,4)==4
            img = imread('all_eaten.png');
        else
            img = imread('init.png');
            img=255-img;
    end
    image('CData',img,'XData',[1 size(layout_mat,2)*100],'YData',[1 size(layout_mat,1)*100])
    h(4)=image(xlim,-ylim,img);
    agent_current_location=state2location(accepted_pathes{mini}(run_num,1));tmp=agent_current_location;
    agent_current_location=(agent_current_location).*100+50;
    
    if run_num>1
    action_indx=determine_action(state2location(accepted_pathes{mini}(run_num-1,1)),current_location);
    switch action_indx
        case 1
            pacman_dir=pacman_d;
        case 2
            pacman_dir=pacman_r;
        case 3
            pacman_dir=pacman_u;
        case 4
            pacman_dir=pacman_l;
    end
    end
       
    imagesc([agent_current_location(2)-markersize_pacman(1) agent_current_location(2)+markersize_pacman(1)],...
        [agent_current_location(1)-markersize_pacman(2) agent_current_location(1)+markersize_pacman(2)],pacman_dir);
    for j=1:size(accepted_pathes{mini}(1,:),2)-2
        ghost_current_location(j,:)=state2location(accepted_pathes{mini}(run_num,2+j-1));ghost_current_location(j,:)=(ghost_current_location(j,:)).*100+50;
        imagesc([ghost_current_location(j,2)-markersize_ghosts(1) ghost_current_location(j,2)+markersize_ghosts(1)],...
        [ghost_current_location(j,1)-markersize_ghosts(2) ghost_current_location(j,1)+markersize_ghosts(2)],imread(sprintf('ghost%d.png',j)));
    end
    view(0,-90)
    xlim([1 size(layout_mat,2)*100])
    ylim([1 size(layout_mat,1)*100])
    title(['Current Location: (',int2str(tmp),'  ',int2str(accepted_pathes{mini}(run_num,4)),')'])
    pbaspect([size(layout_mat,2) size(layout_mat,1) 1])
    drawnow
    pause(.2) 
    frame = getframe;
    writeVideo(v,frame);
end    

for i=1:5
    current_location=state2location(accepted_pathes{mini}(end,1));
    hold on
    if accepted_pathes{mini}(end,4)==1
            img = imread('init.png');
        elseif accepted_pathes{mini}(end,4)==2
            img = imread('number_1_eaten.png');
        elseif accepted_pathes{mini}(end,4)==3
            img = imread('number_2_eaten.png');
        elseif accepted_pathes{mini}(end,4)==4
            img = imread('all_eaten.png');
        else
            img = imread('init.png');
            img=255-img;
    end
    image('CData',img,'XData',[1 size(layout_mat,2)*100],'YData',[1 size(layout_mat,1)*100])
    h(4)=image(xlim,-ylim,img);
    agent_current_location=state2location(accepted_pathes{mini}(end,1));tmp=agent_current_location;
    agent_current_location=(agent_current_location).*100+50;
    imagesc([agent_current_location(2)-markersize_pacman(1) agent_current_location(2)+markersize_pacman(1)],...
        [agent_current_location(1)-markersize_pacman(2) agent_current_location(1)+markersize_pacman(2)],pacman_dir);
    for j=1:size(accepted_pathes{mini}(1,:),2)-2
        ghost_current_location(j,:)=state2location(accepted_pathes{mini}(end,2+j-1));ghost_current_location(j,:)=(ghost_current_location(j,:)).*100+50;
        imagesc([ghost_current_location(j,2)-markersize_ghosts(1) ghost_current_location(j,2)+markersize_ghosts(1)],...
        [ghost_current_location(j,1)-markersize_ghosts(2) ghost_current_location(j,1)+markersize_ghosts(2)],imread(sprintf('ghost%d.png',j)));
    end
    view(0,-90)
    xlim([1 size(layout_mat,2)*100])
    ylim([1 size(layout_mat,1)*100])
    title(['Current Location: (',int2str(tmp),'  ',int2str(accepted_pathes{mini}(end,4)),')'])
    pbaspect([size(layout_mat,2) size(layout_mat,1) 1])
    drawnow
    pause(.2) 
    frame = getframe;
    writeVideo(v,frame);
end

close(v)