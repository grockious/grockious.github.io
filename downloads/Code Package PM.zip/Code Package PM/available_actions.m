function available_actions_at_state=available_actions(state)
available_actions_at_state=[];
global layout_mat wall_loc 
location=state2location(state);
location=location+1;
for i=-2:2
    add=sign(i).*de2bi(abs(i),2);
    next_location(1)=location(1)+add(2);
    next_location(2)=location(2)+add(1);
    if (layout_mat(next_location(1),next_location(2))~=wall_loc)
        if i==1
            action=2;
        elseif i==2
            action=1;
        else
            action=5+i;
        end
        available_actions_at_state=[available_actions_at_state;action];
    end
end