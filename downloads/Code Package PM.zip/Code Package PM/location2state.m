function state=location2state(location)
global X_movable_limit
for i=1:size(location,1)
    state(i)=location(i,1)+(location(i,2)-1).*X_movable_limit;
end
