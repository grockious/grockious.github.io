clear all
dot=[];
fid = fopen('layout.lay');
text_line{1}=fgetl(fid);
i=1;
while ischar(text_line{i})
    i=i+1;
    text_line{i}=fgetl(fid);
end
fclose(fid);
layout_matrix=zeros(size(text_line,2)-1,size(text_line{1},2));
image=zeros(size(layout_matrix,1)*100,size(layout_matrix,2)*100,3); 
for i=1:size(text_line,2)-1
    for j=1:size(text_line{1},2)
        layout_matrix(i,j)=double(text_line{i}(j));
        if layout_matrix(i,j)==37
            image(i*100-99:i*100,j*100-99:j*100,1)=0/255;
            image(i*100-99:i*100,j*100-99:j*100,2)=97/255;
            image(i*100-99:i*100,j*100-99:j*100,3)=255/255;
        elseif layout_matrix(i,j)==46
            dot=[dot;i,j];
            image(i*100-69:i*100-29,j*100-69:j*100-29,1:3)=1;
        end
    end
end
figure, imshow(image)
iptsetpref('ImshowBorder','tight');
set(gca,'position',[0 0 1 1],'units','normalized')
saveas(gcf,'init.png')
close all
for k=1:size(dot,1)
    i=dot(k,1);
    j=dot(k,2);
    image(i*100-69:i*100-29,j*100-69:j*100-29,1:3)=0;
    figure, imshow(image)
    iptsetpref('ImshowBorder','tight');
    set(gca,'position',[0 0 1 1],'units','normalized')
    saveas(gcf,sprintf('number_%d_eaten.png',k))
    close all
    image(i*100-69:i*100-29,j*100-69:j*100-29,1:3)=1;
end
for k=1:size(dot,1)
    i=dot(k,1);
    j=dot(k,2);
    image(i*100-69:i*100-29,j*100-69:j*100-29,1:3)=0;
end
figure, imshow(image)
iptsetpref('ImshowBorder','tight');
set(gca,'position',[0 0 1 1],'units','normalized')
saveas(gcf,'all_eaten.png')
close all
save layout.mat
disp('layout reading was successful')