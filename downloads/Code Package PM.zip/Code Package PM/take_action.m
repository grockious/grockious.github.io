function next_state=take_action(current_state,agent_action_indx)
agent_current_location=state2location(current_state(1));
ghost_current_location=state2location(current_state(2:end-1));

if ~ismember(agent_action_indx,available_actions(current_state(1)))
    agent_action_indx=5;
end

switch agent_action_indx
    case 1
      agent_next_location(1)=agent_current_location(1)+1;  
      agent_next_location(2)=agent_current_location(2);
    case 2
      agent_next_location(1)=agent_current_location(1);  
      agent_next_location(2)=agent_current_location(2)+1;  
    case 3
      agent_next_location(1)=agent_current_location(1)-1;  
      agent_next_location(2)=agent_current_location(2);  
    case 4
      agent_next_location(1)=agent_current_location(1);  
      agent_next_location(2)=agent_current_location(2)-1;  
    case 5
      agent_next_location(1)=agent_current_location(1);  
      agent_next_location(2)=agent_current_location(2);  
end
agent_next_state=location2state(agent_next_location);
if ismember(agent_next_state,current_state(2:end-1))
    agent_next_location(1)=agent_current_location(1);  
    agent_next_location(2)=agent_current_location(2);
    agent_next_state=location2state(agent_next_location);
end

global G ghosts_determinism
for i=1:size(ghost_current_location,1)
    if rand<ghosts_determinism
        ghost_next_state_temp=shortestpath(graph(G(1,:),G(2,:)),current_state(2+i-1),agent_next_state);
        ghost_next_state(i)=ghost_next_state_temp(2);
        ghost_next_location(i,:)=state2location(ghost_next_state(i));
    else
        ghost_action_indx(i)=floor(5*rand)+1;
        if ~ismember(ghost_action_indx(i),available_actions(current_state(2+i-1)))
            ghost_action_indx(i)=5;
        end
        switch ghost_action_indx(i)
            case 1
              ghost_next_location(i,1)=ghost_current_location(i,1)+1;  
              ghost_next_location(i,2)=ghost_current_location(i,2);
            case 2
              ghost_next_location(i,1)=ghost_current_location(i,1);  
              ghost_next_location(i,2)=ghost_current_location(i,2)+1;  
            case 3
              ghost_next_location(i,1)=ghost_current_location(i,1)-1;  
              ghost_next_location(i,2)=ghost_current_location(i,2);  
            case 4
              ghost_next_location(i,1)=ghost_current_location(i,1);  
              ghost_next_location(i,2)=ghost_current_location(i,2)-1;  
            case 5
              ghost_next_location(i,1)=ghost_current_location(i,1);  
              ghost_next_location(i,2)=ghost_current_location(i,2);  
        end
    end
end
 
%%Assignment matrix
global a b ghost neutral X_movable_limit Y_movable_limit layout_mat food_loc
u=neutral.*ones(X_movable_limit,Y_movable_limit);
[r,c]=find(ismember(layout_mat,food_loc));
labels=[a,b];
for i=1:size(r,1)
    u(r(i)-1,c(i)-1)=labels(i);
end

for i=1:size(ghost_current_location,1)
    if (agent_next_location(1)==ghost_next_location(i,1) && agent_next_location(2)==ghost_next_location(i,2))
        u(agent_next_location(1),agent_next_location(2))=ghost;
    end
end
 
automaton_depth=automaton(u(agent_next_location(1),agent_next_location(2)),current_state(4));
ghosts_next_state=location2state(ghost_next_location);
next_state=[agent_next_state,ghosts_next_state,automaton_depth];